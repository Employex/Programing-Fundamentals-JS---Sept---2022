let uniqueNames = new Set();

uniqueNames.add('Pesho');
uniqueNames.add('Gosho');
uniqueNames.add('Stamat');
uniqueNames.add('Pesho');

console.log(uniqueNames);
