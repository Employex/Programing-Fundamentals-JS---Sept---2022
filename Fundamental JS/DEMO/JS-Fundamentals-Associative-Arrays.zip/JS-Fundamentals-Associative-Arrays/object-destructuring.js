const phoneBook = {
    ivaylo: '11651621',
    pesho: '11651623',
    gosho: '11651634',
    stamat: '11651645',
    mariyka: '11651624',
};

let { mariyka, gosho } = phoneBook;
console.log(mariyka);
console.log(gosho);


